from django.shortcuts import render,HttpResponse

def api(request):
    data = HttpResponse('你好好爱好是')
    data['Access-Control-Allow-Origin'] = '*'
    return data
