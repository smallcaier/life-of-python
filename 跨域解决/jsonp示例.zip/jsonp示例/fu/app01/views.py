from django.shortcuts import render,HttpResponse

def api(request):
    func = request.GET.get('callback')
    return HttpResponse('x1("你好好爱好是")')
